workforce-wellbeing-insights/
│
├── workforce_data.csv
├── workforce_dashboard.pbix
├── README.md
└── images/
    └── dashboard.png
